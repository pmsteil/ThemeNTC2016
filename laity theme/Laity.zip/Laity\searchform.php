
                  <form role="search" name="search" class="form-search" method="get" action="/">
                    <input type="text" name="CAT_Search" title="site search" class="txt" id="CAT_Search" accesskey="4">
                    <input type="submit" class="btn-submit cat_button" value="Search">
                  </form>
                